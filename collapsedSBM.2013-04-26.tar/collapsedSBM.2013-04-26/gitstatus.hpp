
extern const char * gitstatus;
