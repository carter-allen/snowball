#ifndef _GRAPH_SAVING_HPP_
#define _GRAPH_SAVING_HPP_

#include "network.hpp"
namespace graph {
namespace saving {

void print_Network_to_screen( const NetworkInterfaceConvertedToStringWithWeights * net );

} // namespace graph
} // namespace saving

#endif
