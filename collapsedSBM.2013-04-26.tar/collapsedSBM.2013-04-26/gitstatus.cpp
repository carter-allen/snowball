#include "gitstatus.hpp"
const char gitstatus_[] = 
#include "comment.txt"
"====\n"
#include "gitstatus.txt"
;
const char * gitstatus = gitstatus_;
